﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<string> str = new List<string>() { "Ekta", "Akansha", "Sayli", "Snehal", "Vaija", "Mom", "Sis" };
            foreach (var item in str)
            {
                if (item.Length % 2 != 0 && item.Contains("a") == true)
                {
                    Console.WriteLine(item);
                }
            }

            Console.ReadLine();
        }
    }
}

