﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class baseClass
    {
       
        protected virtual void show()
        {
            Console.WriteLine("Base class");
        }
    }

    class derived : baseClass
    {

        public void show1()
        {
            Console.WriteLine("Derived class");
        }
    }

    public class main
    {
        public static void Main()
        { 
        
            derived obj;
            obj = new derived();
            obj.show1();
            obj.show();
        }
    }
}