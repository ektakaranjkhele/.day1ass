﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
  public  class Bank
    {
      public  int NetBal1;
       public int TAmount;
        public Bank(int NetBal1, int TAmount)
        {
            this.NetBal1 = NetBal1;
            this.TAmount = TAmount;
        }
        
        public int NetBalance
        {
            get { return NetBal1; }
            set { NetBal1 = value; }
        }

        public void Deposit()
        {
            NetBalance = NetBalance + TAmount;
            Console.WriteLine("deposit..." + NetBalance);
        }



       public void Withdrawal()
        {

            NetBalance = NetBalance - TAmount;
            Console.WriteLine("withdraw..." + NetBalance);
        }


    }
}
